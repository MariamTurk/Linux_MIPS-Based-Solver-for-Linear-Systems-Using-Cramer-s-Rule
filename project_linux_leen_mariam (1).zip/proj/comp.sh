#!/bin/bash

# Check if two arguments are provided
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <gNMI_file_path> <CLI_file_path>"
    exit 1
fi

# Assign input arguments to variables
gnmi_file="$1"
cli_file="$2"

# Check if files exist
if [ ! -f "$gnmi_file" ]; then
    echo "Error: gNMI file '$gnmi_file' does not exist."
    exit 1
fi

if [ ! -f "$cli_file" ]; then
    echo "Error: CLI file '$cli_file' does not exist."
    exit 1
fi

# Parse gNMI file into an associative array
declare -A gnmi_data
while IFS=': ' read -r key value; do
    key=$(echo "$key" | tr -d '"{}, ')  # Remove unwanted characters
    value=$(echo "$value" | tr -d '"{}, ')
    gnmi_data["$key"]="$value"
done < <(grep ":" "$gnmi_file")

# Parse CLI file into an associative array
declare -A cli_data
while IFS=': ' read -r key value; do
    key=$(echo "$key" | tr -d '"{}, ')  # Remove unwanted characters
    value=$(echo "$value" | tr -d '"{}, ')
    cli_data["$key"]="$value"
done < "$cli_file"

# Compare the data
echo "Comparison Results:"
echo "==================="
for key in "${!gnmi_data[@]}"; do
    gnmi_value="${gnmi_data[$key]}"
    cli_value="${cli_data[$key]}"

    if [ "$gnmi_value" == "$cli_value" ]; then
        echo "Key: $key - Match"
    else
        echo "Key: $key - Mismatch (gNMI: $gnmi_value, CLI: $cli_value)"
    fi
done

# Check for keys in CLI data missing from gNMI data
for key in "${!cli_data[@]}"; do
    if [ -z "${gnmi_data[$key]}" ]; then
        echo "Key: $key - Present in CLI but missing in gNMI"
    fi
done
