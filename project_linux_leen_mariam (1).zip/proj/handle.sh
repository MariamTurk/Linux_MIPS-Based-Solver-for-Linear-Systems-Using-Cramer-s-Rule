#!/bin/bash

# At least two arguments are provided
if [ "$#" -lt 2 ]; then
    echo "You need to provide a gNMI path and at least one CLI command"
    exit 1
fi

# Assigning input arguments
gnmi_path="$1"  # First argument: gNMI path
shift           # Shift to access the CLI commands
cli_commands=("$@")  # Remaining arguments: CLI commands

# Map gNMI path to file
echo "gNMI Path: $gnmi_path"
gnmi_file=$(echo "$gnmi_path" \
    | sed 's/\[id=\(.*\)\]/_\1/' \
    | sed 's/\[neighbor_address=\(.*\)\]/_\1/' \
    | sed 's/\[name=\(.*\)\]/_\1/' \
    | sed 's/\[\(.*\)\]/_/g' \
    | sed 's/^\///')
gnmi_file="${gnmi_file}/gnmi_data.txt"
echo "Transformed gNMI File Path: $gnmi_file"

# Validate gNMI file existence
if [ ! -f "$gnmi_file" ]; then
    echo "Error: gNMI file '$gnmi_file' does not exist."
    exit 1
fi

# Map and validate CLI files
cli_files=()
for cmd in "${cli_commands[@]}"; do
    # Special case for 'show interfaces eth0 status'
    if [ "$cmd" == "show interfaces eth0 status" ]; then
        cli_file="cli_outputs/$(echo "$cmd" | tr ' ' '' | tr '-' '')_1.txt"
    else
        cli_file="cli_outputs/$(echo "$cmd" | tr ' ' '' | tr '-' '').txt"
    fi

    echo "Mapped CLI Command: $cmd -> $cli_file"

    if [ ! -f "$cli_file" ]; then
        echo "Error: CLI file '$cli_file' does not exist."
        exit 1
    fi

    cli_files+=("$cli_file")  # Store the file path
done

# Helper function to parse nested JSON arrays
parse_json_array() {
    echo "$1" | sed -E 's/^\[|\]$//g' | tr '}' '\n' | sed -E 's/^[[:space:]]*|[[:space:]]*$//g' | tr -d '{' | sed -E 's/,/\n/g'
}

# Parse and compare gNMI and CLI files
declare -A gnmi_data
declare -A cli_data

# Parse gNMI file
while IFS=': ' read -r key value; do
    key=$(echo "$key" | tr -d '"{}, ')  # Clean up key
    value=$(echo "$value" | tr -d '"{}, ')  # Clean up value
    gnmi_data["$key"]="$value"
done < <(grep ":" "$gnmi_file")

# Parse multiple CLI files and combine their data
for cli_file in "${cli_files[@]}"; do
    while IFS=': ' read -r key value; do
        key=$(echo "$key" | tr -d '"{}, ')  # Clean up key
        value=$(echo "$value" | tr -d '"{}, ')  # Clean up value
        cli_data["$key"]="$value"
    done < "$cli_file"
done

# Generate Report
report_file="comparison_report.txt"

{
    echo "Comparison Report"
    echo "gNMI Path: $gnmi_path"
    echo "CLI Commands: ${cli_commands[*]}"
    echo ""
    echo "Comparison Results:"
    echo "....................................."

    # Compare gNMI and CLI data
    for key in "${!gnmi_data[@]}"; do
        gnmi_value="${gnmi_data[$key]}"
        cli_value="${cli_data[$key]}"

        if [[ "$key" == "adjacencies" ]]; then
            continue
        fi

        if [ -z "$cli_value" ]; then
            echo "$key : Present in gNMI but missing in CLI"
        elif [ "$gnmi_value" == "$cli_value" ]; then
            echo "$key : Match"
        else
            echo "$key : Mismatch (gNMI: $gnmi_value, CLI: $cli_value)"
        fi
    done

    # Check for keys in CLI data missing from gNMI data
    for key in "${!cli_data[@]}"; do
        if [[ "$key" == "adjacencies" ]]; then
            continue
        fi
        if [ -z "${gnmi_data[$key]}" ]; then
            echo "$key : Present in CLI but missing in gNMI"
        fi
    done
} > "$report_file"

echo "Report saved to $report_file"
