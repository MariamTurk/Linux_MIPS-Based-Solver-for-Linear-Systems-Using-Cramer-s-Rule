#!/bin/bash

# Step 1: Ensure at least two arguments are provided
if [ "$#" -lt 2 ]; then
    echo "Usage: $0 <gNMI_path> <CLI_command1> [CLI_command2] ..."
    exit 1
fi

# Step 2: Assign input arguments
gnmi_path="$1"            # First argument: gNMI path
shift                     # Shift to access the CLI commands
cli_commands=("$@")       # Remaining arguments: CLI commands

# Step 3: Map gNMI path to file
echo "Original gNMI Path: $gnmi_path"
gnmi_file=$(echo "$gnmi_path" \
    | sed 's/\[id=\(.*\)\]/_\1/' \
    | sed 's/\[neighbor_address=\(.*\)\]/_\1/' \
    | sed 's/\[name=\(.*\)\]/_\1/' \
    | sed 's/\[\(.*\)\]/_/g' \
    | sed 's/^\///' \
    | sed 's/-/_/g')  # Replace "-" with "_"
gnmi_file="${gnmi_file}/gnmi_data.txt"
echo "Transformed gNMI File Path: $gnmi_file"

# Step 4: Validate gNMI file existence
if [ ! -f "$gnmi_file" ]; then
    echo "Error: gNMI file '$gnmi_file' does not exist."
    exit 1
fi

# Step 5: Map and validate CLI files
cli_files=()
for cmd in "${cli_commands[@]}"; do
    sanitized_cmd=$(echo "$cmd" | sed 's/-/_/g')
    cli_file="cli_outputs/$(echo "$sanitized_cmd" | tr ' ' '_' | tr -d ':')"
    cli_file="${cli_file}.txt"
    echo "Mapped CLI Command: $cmd -> $cli_file"

    if [ ! -f "$cli_file" ]; then
        echo "Error: CLI file '$cli_file' does not exist."
        exit 1
    fi

    cli_files+=("$cli_file")  # Store the file path
done

# Helper functions
normalize_string() {
    echo "$1" | tr '[:upper:]' '[:lower:]' | xargs
}

convert_units() {
    value="$1"
    if [[ "$value" =~ ^([0-9.]+)([a-zA-Z]*)$ ]]; then
        num="${BASH_REMATCH[1]}"
        unit="${BASH_REMATCH[2]}"
        case "$unit" in
            "kb") echo "$(echo "$num * 1024" | bc)" ;;
            "mb") echo "$(echo "$num * 1024 * 1024" | bc)" ;;
            "gb") echo "$(echo "$num * 1024 * 1024 * 1024" | bc)" ;;
            "g") echo "$(echo "$num * 1000000000" | bc)" ;;
            "%"|"percent") echo "$num" ;; # Strip percentage
            "b"|"") echo "$num" ;;
            *) echo "$num" ;;
        esac
    else
        echo "$value"
    fi
}

adjust_precision() {
    if [[ "$1" =~ ^[0-9.]+$ ]]; then
        printf "%.2f" "$1"
    else
        echo "N/A"
    fi
}

# Parse and compare gNMI and CLI files
report_file="comparison_report.txt"
{
    echo "Comparison Report"
    echo "---------------------"
    echo "gNMI Path: $gnmi_path"
    echo "CLI Commands: ${cli_commands[*]}"
    echo ""
    echo "Comparison Results:"
    echo "---------------------"

    for cli_file in "${cli_files[@]}"; do
        while IFS=': ' read -r key value; do
            gNMI_value=$(grep -i "^$key:" "$gnmi_file" | awk -F': ' '{print $2}' | xargs)
            CLI_value=$(echo "$value" | xargs)

            # Ensure gNMI_value and CLI_value are printed
            echo "Path: $gnmi_path"
            echo "o Key: $key"
            

            # Normalize and process values for comparison
            gNMI_normalized=$(normalize_string "$gNMI_value")
            CLI_normalized=$(normalize_string "$CLI_value")
            gNMI_converted=$(convert_units "$gNMI_value")
            CLI_converted=$(convert_units "$CLI_value")
            gNMI_adjusted=$(adjust_precision "$gNMI_converted")
            CLI_adjusted=$(adjust_precision "$CLI_converted")

            # Case 1: Match after normalization
            if [[ "$gNMI_normalized" == "$CLI_normalized" ]]; then
                echo "o Result: Match after adition"
            # Case 2: Match after conversion
            elif [[ "$gNMI_converted" == "$CLI_converted" ]]; then
                echo "o Result: Match after adition"
            # Case 3: Match after adjusting precision
            elif [[ "$gNMI_adjusted" == "$CLI_adjusted" ]]; then
                echo "o Result: Match after adition"
            else
                echo "o Result: Mismatch (gNMI: ${gNMI_adjusted:-N/A}, CLI: ${CLI_adjusted:-N/A})."
            fi
            echo ""
        done < "$cli_file"
    done
} > "$report_file"

echo "Report saved to $report_file"

